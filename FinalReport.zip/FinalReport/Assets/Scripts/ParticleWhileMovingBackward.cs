﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleWhileMovingBackward : MonoBehaviour
{

    public ParticleSystem ParticleWhileBackward;

    public static bool movingBackward;

    void Start()
    {
        movingBackward = false;
    }

    void Update()
    {
        ParticleWhileBackward.transform.position = new Vector3(transform.position.x,
            (transform.position.y - 0.4f), 0);

        ParticlesPlayBackward();
    }

    private void ParticlesPlayBackward()
    {
        if (movingBackward == true)
        {
            ParticleWhileBackward.Play();
            movingBackward = false;
        }
    }

    public static void BackSetter()
    {
        movingBackward = true;
    }
}
