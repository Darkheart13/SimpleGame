using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{

    public Rigidbody2D carRigidBody;
    public Rigidbody2D backWheel;
    public Rigidbody2D frontWheel;

    public ParticleSystem frontWheelForwardPS;
    public ParticleSystem frontWheelBackwardPS;
    public ParticleSystem backWheelForwardPS;
    public ParticleSystem backWheelBackwardPS;

    private float startPosX;
    private float startPosY;

    public float speed = 20;
    public float torque = 10;

    //private float maxSpeed = 200f;

    public float trashHold;

    private bool LeftMove;
    public bool LightOn;
    private bool isBeingHeld;

    public SpriteRenderer carRenderer;

    public AudioClip BrakeSong;
    public AudioClip SignalSong;
    private AudioSource Audio;

    public Animator CarAnimation;

    private void Start()
    {
        Audio = GetComponent<AudioSource>();
    }

    void Update()
    {
        MouseControll();
        KeyboardControll();
    }

    private void FixedUpdate()
    {
        //carRigidBody.velocity = Vector2.ClampMagnitude(carRigidBody.velocity, maxSpeed);
    }

    private void MouseControll()
    {
        if (Input.GetMouseButton(0))
        {
            if (isBeingHeld)
            {
                Vector3 mousePos = Input.mousePosition;
                mousePos = Camera.main.ScreenToWorldPoint(mousePos);
                carRigidBody.transform.localPosition = new Vector3(mousePos.x - startPosX, mousePos.y - startPosY, 0);
            }
        }
    }

    bool lastLeftMove = false;
    private void KeyboardControll()
    {
        float middle = Screen.width / 3;

        if (Input.GetKey(KeyCode.LeftArrow) || (Input.GetMouseButtonDown(0) && Input.mousePosition.x < middle))
        {
            LeftMove = true;
            Drive(1);
            CarAnimation.SetBool("isBraking", true);

        }
        else if (Input.GetKey(KeyCode.RightArrow) || (Input.GetMouseButtonDown(0) && Input.mousePosition.x > 2 * middle))
        {
            LeftMove = false;
            Drive(-1);
        }
        else if (Input.anyKeyDown && !Input.GetKey(KeyCode.Space))
        {
            AnyKeyPressed();
        }
        else if (Input.GetKey(KeyCode.Space))
        {
            SpaceKeyPressed();
        }
        else
        {
            CarAnimation.SetBool("isBraking", false);
        }
        if (lastLeftMove != LeftMove && carRigidBody.velocity.x > trashHold)
        {
            PlayParticle(!lastLeftMove);
        }
        lastLeftMove = LeftMove;
    }

    private void Drive(int sign)
    {
        backWheel.AddTorque(sign * speed * Time.fixedDeltaTime);
        frontWheel.AddTorque(sign * speed * Time.fixedDeltaTime);
        carRigidBody.AddTorque(sign * torque * Time.fixedDeltaTime);
        //JointMotor2D motor = new JointMotor2D();
        //motor.motorSpeed = -sign * speed * Time.fixedDeltaTime;
        //backWheelJoint.motor = motor;
        //frontWheelJoint.motor = motor;
    }

    public void Brake() // WORKS GOOD
    {
            frontWheel.angularVelocity = 0;
            backWheel.angularVelocity = 0;
    }

    private void SpaceKeyPressed() // CONFIGURE SOUND AND THATS IT
    {
        Audio.clip = BrakeSong;
        Audio.Play();
        Brake();
        CarAnimation.SetBool("isBraking", true);
    }

    private void AnyKeyPressed() // WORKS GOOD
    {
        if(LightOn) LightOn = false;
        else LightOn = true;

        Audio.clip = SignalSong;
        Audio.Play();
        RaiseLittleBit();
        CarAnimation.SetTrigger("isLightsOn");
        CarAnimation.SetBool("lightsIDLE", LightOn);
    }

    public void RaiseLittleBit() // WORKS GOOD
    {
        carRigidBody.transform.position = new
            Vector2(carRigidBody.transform.position.x,
            carRigidBody.transform.position.y + 0.06f);
    }

    private void OnMouseDown() //WORKS GOOD
    {
        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("Down");
            Vector3 mousePos = Input.mousePosition;
            mousePos = Camera.main.ScreenToWorldPoint(mousePos);

            startPosX = mousePos.x - carRigidBody.transform.localPosition.x;
            startPosY = mousePos.y - carRigidBody.transform.localPosition.y;

            isBeingHeld = true;
        }
    }

    private void OnMouseUp() // WORKS GOOD
    {
        isBeingHeld = false;
    }

    private void PlayParticle(bool movingRight)
    {
        if (movingRight)
        {
            frontWheelForwardPS.Play();
            backWheelForwardPS.Play();
        }
        else
        {
            backWheelBackwardPS.Play();
            frontWheelBackwardPS.Play();
        }
    }
}
