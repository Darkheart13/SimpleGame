﻿using UnityEngine;

public class RotationController : MonoBehaviour
{
    public Rigidbody2D carBodyRigidBody;

    public void Update()
    {
        FixAngle();
    }

    public void FixAngle()
    {
        float maxAgnle = 30f;

        bool isRotatedOverMaxAngle = ((transform.localEulerAngles.z > maxAgnle) && (transform.eulerAngles.z < 180f));

        bool isRotatedLowerMaxAngle = ((transform.localEulerAngles.z < (360 - maxAgnle)) && (transform.eulerAngles.z > 180f));

        if (isRotatedOverMaxAngle)
        {
            carBodyRigidBody.angularVelocity = 0f;
            transform.localEulerAngles = new Vector3(0, 0, 30f);
            carBodyRigidBody.AddTorque(-20f);
        }
        else if (isRotatedLowerMaxAngle)
        {
            carBodyRigidBody.angularVelocity = 0f;
            transform.localEulerAngles = new Vector3(0, 0, 360 - maxAgnle);
            carBodyRigidBody.AddTorque(20f);
        }
    }
}
