﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleWhileMovingForward : MonoBehaviour
{

    public ParticleSystem ParticleWhileForward;
    private static bool movingForward;

    void Start()
    {
        movingForward = false;
    }

    void Update()
    {
        ParticleWhileForward.transform.position = new Vector3(transform.position.x,
                    transform.position.y - 0.4f, 0);
        //ParticlesPlayForward();
    }

    private void ParticlesPlayForward()
    {
        if (movingForward == true)
        {
            ParticleWhileForward.Play();
            movingForward = false;
        }
    }

    public static void FrontSetter()
    {
        movingForward = true;
    }
}
